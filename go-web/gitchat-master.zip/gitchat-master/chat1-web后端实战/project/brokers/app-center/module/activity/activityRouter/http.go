package activityRouter

import "github.com/gin-gonic/gin"

func HTTPRouter(r gin.IRoutes) {

}

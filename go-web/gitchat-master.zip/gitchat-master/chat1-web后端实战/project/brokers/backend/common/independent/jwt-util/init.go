package jwt_util

var JwtTool Jwt
func init() {
	JwtTool = NewJwtTool("88mkva4N{3m47/sm")
}

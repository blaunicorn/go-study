package activityService

import "github.com/gin-gonic/gin"

func AddActivity(c *gin.Context) {

}
func ListActivity(c *gin.Context){

}

func ModifyActivity(c *gin.Context){

}

func GetUserActivityProcess(c *gin.Context) {
}

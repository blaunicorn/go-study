package userModel

type BackendUser struct{
}
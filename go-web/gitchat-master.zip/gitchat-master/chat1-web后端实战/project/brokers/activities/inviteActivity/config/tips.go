package config

var Tips = map[int]string{
	 1: "未授权来源",
}
